### Description:


### Installation method:
- [ ] Carthage
- [ ] CocoaPods(1.1.0 or later)
- [ ] Swift Package Manager
- [ ] Manually
- [ ] other: ()

### Library version:
- [ ] v2.1.1
- [ ] other: ()

### Xcode version:
- [ ] 8.1 (Swift 3) 
- [ ] 8.1 (Swift 2.3)
- [ ] 7.3.1
- [ ] other: ()
